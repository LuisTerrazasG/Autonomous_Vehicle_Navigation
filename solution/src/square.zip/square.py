#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32
from geometry_msgs.msg import Twist
from math import pi

class square:
        def __init__(self):

            self.wr = 0.00
            self.wl = 0.00


            rospy.Subscriber('/wr', Float32, self.wr_callback)
            rospy.Subscriber('/wl', Float32, self.wl_callback)

            self.w_pub = rospy.Publisher('/cmd_vel', Twist,queue_size=10)

            rospy.init_node("Square")
            self.rate = rospy.Rate(10)

            rospy.on_shutdown(self.stop)


        def wr_callback(self,msg):
            self.wr = msg.data

        def wl_callback(self,msg):
            self.wl = msg.data

        def run(self):

            distance = 0.0
            angle = 0.0
            current_time = rospy.get_time()
            last_time = rospy.get_time()
            state  = 0
            count = 1
            no_sides = 4


            msg = Twist()
            msg.linear.x = 0
            msg.linear.y = 0
            msg.linear.z = 0
            msg.angular.x = 0
            msg.angular.y = 0
            msg.angular.z = 0

            while not rospy.is_shutdown():
                current_time = rospy.get_time()
                dt = current_time - last_time
                last_time = current_time
                

                distance += 0.05 * (self.wr + self.wl) * 0.5 * dt
                print(distance)
                angle += 0.05 * (self.wr - self.wl) / 0.18 * dt
                self.wr = 0
                self.wl = 0

                if state == 0:
                    msg.linear.x = 0.25
                    msg.angular.z = 0.0

                    if distance > 0.88:
                        print("Estoy cambiando estado")
                        distance = 0.0

                        if count < no_sides:
                            print("Cambie a estado 1")
                            state = 1
                            count += 1
                        else:
                            state = 2
                            print("Cambie a estado 2")

                elif state == 1:
                    msg.linear.x = 0.0
                    msg.angular.z = 0.08

                    if angle > 1.49:
                        angle = 0.0
                        state = 0

                elif state == 2 :

                    msg.linear.x = 0
                    msg.linear.z = 0
                    print("Motion Completed")
                    rospy.signal_shutdown("Square Completed")

                else:
                    msg.linear.x = 0
                    msg.angular.z = 0

                self.w_pub.publish(msg)
                self.rate.sleep()

        def stop(self):
            print("Stopping")
            msg = Twist()
            msg.linear.x = 0
            msg.linear.y = 0
            msg.linear.z = 0
            msg.angular.x = 0
            msg.angular.y = 0
            msg.angular.z = 0
            self.w_pub.publish(msg)

if __name__ == "__main__":

    sq = square()
    try:
        sq.run()
    except rospy.ROSInterruptException:
        None